package com.boltehi.voicetyping.accessibility

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TextInjector @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val clipboardManager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    private val mainHandler = Handler(Looper.getMainLooper())

    fun injectOrCopyToClipboard(transcribedText: String, onComplete: (success: Boolean, usedClipboard: Boolean) -> Unit) {
        val service = VoiceTypingAccessibilityService.getInstance()
        val success = service?.injectText(transcribedText) ?: false

        if (success) {
            onComplete(true, false)
        } else {
            // Fallback: Copy to clipboard and notify user
            val clip = ClipData.newPlainText("Transcribed Voice", transcribedText)
            clipboardManager.setPrimaryClip(clip)

            mainHandler.post {
                Toast.makeText(
                    context,
                    "ক্লিপবোর্ডে কপি করা হয়েছে (পেস্ট করুন)",
                    Toast.LENGTH_SHORT
                ).show()
            }
            onComplete(true, true)
        }
    }
}