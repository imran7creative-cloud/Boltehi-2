package com.boltehi.voicetyping.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    apiKey: String,
    model: String,
    language: String,
    autoPunctuation: Boolean,
    isOverlayPermissionGranted: Boolean,
    isAccessibilityGranted: Boolean,
    onSaveApiKey: (String) -> Unit,
    onModelChange: (String) -> Unit,
    onLanguageChange: (String) -> Unit,
    onAutoPunctuationChange: (Boolean) -> Unit,
    onRequestOverlayPermission: () -> Unit,
    onRequestAccessibilityPermission: () -> Unit
) {
    var keyInput by remember(apiKey) { mutableStateOf(apiKey) }
    var isKeyVisible by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Boltehi Settings", fontWeight = FontWeight.SemiBold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // Permission Audit Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("System Permissions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Draw Over Other Apps", fontWeight = FontWeight.Medium)
                            Text("Displays floating mic bubble", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                        if (isOverlayPermissionGranted) {
                            Text("Enabled", color = Color(0xFF059669), fontWeight = FontWeight.Bold)
                        } else {
                            Button(onClick = onRequestOverlayPermission) { Text("Allow") }
                        }
                    }

                    HorizontalDivider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Accessibility Service", fontWeight = FontWeight.Medium)
                            Text("Detects input fields & injects text", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                        if (isAccessibilityGranted) {
                            Text("Active", color = Color(0xFF059669), fontWeight = FontWeight.Bold)
                        } else {
                            Button(onClick = onRequestAccessibilityPermission) { Text("Activate") }
                        }
                    }
                }
            }

            // Groq API Key Section
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Groq Whisper API Key", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    "Your API key is encrypted on-device with AES-256 and never leaves your phone except for Groq calls.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = keyInput,
                    onValueChange = {
                        keyInput = it
                        onSaveApiKey(it)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("gsk_...") },
                    leadingIcon = { Icon(Icons.Default.Key, contentDescription = null) },
                    trailingIcon = {
                        IconButton(onClick = { isKeyVisible = !isKeyVisible }) {
                            Icon(
                                if (isKeyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = null
                            )
                        }
                    },
                    visualTransformation = if (isKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    singleLine = true
                )
            }

            // Language & Model
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Transcription Engine", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Auto-Punctuation")
                    Switch(checked = autoPunctuation, onCheckedChange = onAutoPunctuationChange)
                }
            }
        }
    }
}