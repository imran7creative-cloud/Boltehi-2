# Boltehi — System-Wide Voice Typing for Android (Kotlin + Jetpack Compose)

Boltehi is an ultra-fast system-wide voice-to-text application for Android. It floats over any application (WhatsApp, Messenger, Chrome, Notes) and uses the **Groq Whisper API** (whisper-large-v3) for real-time dictation, injecting text directly into focused fields via an Android **AccessibilityService**.

## 🛠️ Architecture Overview (Clean Architecture + MVVM)
- **:app**: Application class, Hilt dependency injection setup, AndroidManifest.xml.
- **:core-overlay**: WindowManager TYPE_APPLICATION_OVERLAY manager, Jetpack Compose draggable floating bubble UI with edge-snapping and haptic feedback.
- **:core-accessibility**: VoiceTypingAccessibilityService tracking focused node and performing ACTION_SET_TEXT injection with clipboard fallback.
- **:core-audio**: AudioRecord 16kHz Mono 16-bit PCM recorder, WAV encoder.
- **:core-network**: Retrofit OkHttp client connecting to `https://api.groq.com/openai/v1/audio/transcriptions`.
- **:core-datastore**: EncryptedSharedPreferences (AES-256) storing user Groq API key locally.
- **:feature-settings**: Jetpack Compose Material 3 settings interface.

## 🚀 How to Run in Android Studio
1. Open Android Studio (Ladybug / Koala / Iguana or later).
2. Choose **Open** and select the unzipped directory.
3. Sync Gradle and ensure JDK 17 or JDK 21 is selected in Gradle Settings.
4. Run on a physical Android device or emulator with API Level 26 (Android 8.0) or higher.
5. In the app:
   - Grant **Display over other apps** (SYSTEM_ALERT_WINDOW).
   - Enable **Boltehi Voice Typing** in Android Accessibility Settings.
   - Grant **Microphone** permission.
   - Enter your **Groq Whisper API Key** in Settings.

## 🔒 Google Play Policy Compliance (Accessibility Service)
Because this app uses `BIND_ACCESSIBILITY_SERVICE`, Google Play requires:
1. In-App Prominent Disclosure before requesting permission.
2. Clear explanation: Accessibility is used solely to detect the currently focused text field and paste/inject transcribed voice text on user tap.
3. No user data, passwords, or personal keystrokes are recorded or stored.