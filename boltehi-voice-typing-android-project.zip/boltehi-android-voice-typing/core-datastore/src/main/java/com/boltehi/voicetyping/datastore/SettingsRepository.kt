package com.boltehi.voicetyping.datastore

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        private const val PREFS_NAME = "boltehi_secure_settings"
        private const val KEY_API_KEY = "groq_api_key"
        private const val KEY_MODEL = "groq_model"
        private const val KEY_LANG = "language"
        private const val KEY_PUNCTUATION = "auto_punctuation"
        private const val KEY_BUBBLE_SIZE = "bubble_size"
        private const val KEY_BUBBLE_ALPHA = "bubble_alpha"
    }

    private val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
    private val prefs = EncryptedSharedPreferences.create(
        PREFS_NAME,
        masterKeyAlias,
        context,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private val _apiKeyFlow = MutableStateFlow(prefs.getString(KEY_API_KEY, "") ?: "")
    val apiKeyFlow: StateFlow<String> = _apiKeyFlow

    private val _modelFlow = MutableStateFlow(prefs.getString(KEY_MODEL, "whisper-large-v3") ?: "whisper-large-v3")
    val modelFlow: StateFlow<String> = _modelFlow

    private val _languageFlow = MutableStateFlow(prefs.getString(KEY_LANG, "auto") ?: "auto")
    val languageFlow: StateFlow<String> = _languageFlow

    private val _autoPunctuationFlow = MutableStateFlow(prefs.getBoolean(KEY_PUNCTUATION, true))
    val autoPunctuationFlow: StateFlow<Boolean> = _autoPunctuationFlow

    fun setApiKey(key: String) {
        prefs.edit().putString(KEY_API_KEY, key.trim()).apply()
        _apiKeyFlow.value = key.trim()
    }

    fun setModel(model: String) {
        prefs.edit().putString(KEY_MODEL, model).apply()
        _modelFlow.value = model
    }

    fun setLanguage(lang: String) {
        prefs.edit().putString(KEY_LANG, lang).apply()
        _languageFlow.value = lang
    }

    fun setAutoPunctuation(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_PUNCTUATION, enabled).apply()
        _autoPunctuationFlow.value = enabled
    }
}