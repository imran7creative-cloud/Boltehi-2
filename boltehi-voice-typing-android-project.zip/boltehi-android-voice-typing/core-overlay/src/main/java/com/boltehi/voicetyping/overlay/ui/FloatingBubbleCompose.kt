package com.boltehi.voicetyping.overlay.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PriorityHigh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp

enum class BubbleState {
    IDLE,
    RECORDING,
    PROCESSING,
    SUCCESS,
    ERROR
}

@Composable
fun FloatingBubble(
    state: BubbleState,
    bubbleSizeDp: Int = 56,
    bubbleAlpha: Float = 0.95f,
    onTap: () -> Unit,
    onDragDelta: (dx: Float, dy: Float) -> Unit,
    onDragEnd: () -> Unit
) {
    // Pulse animation during recording
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    val backgroundColor by animateColorAsState(
        targetValue = when (state) {
            BubbleState.IDLE -> Color(0xFF1E293B)       // Slate 800
            BubbleState.RECORDING -> Color(0xFFDC2626)  // Red 600
            BubbleState.PROCESSING -> Color(0xFF2563EB) // Blue 600
            BubbleState.SUCCESS -> Color(0xFF059669)    // Emerald 600
            BubbleState.ERROR -> Color(0xFFEA580C)      // Amber 600
        },
        label = "bgColor"
    )

    Box(
        modifier = Modifier
            .size((bubbleSizeDp + 16).dp)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragEnd = onDragEnd,
                    onDrag = { change, dragAmount ->
                        change.consume()
                        onDragDelta(dragAmount.x, dragAmount.y)
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        // Outer pulsing wave during recording
        if (state == BubbleState.RECORDING) {
            Box(
                modifier = Modifier
                    .size(bubbleSizeDp.dp)
                    .scale(pulseScale)
                    .clip(CircleShape)
                    .background(Color(0xFFDC2626).copy(alpha = 0.35f))
            )
        }

        // Main Bubble Circle
        Box(
            modifier = Modifier
                .size(bubbleSizeDp.dp)
                .shadow(elevation = 8.dp, shape = CircleShape)
                .clip(CircleShape)
                .background(backgroundColor.copy(alpha = bubbleAlpha)),
            contentAlignment = Alignment.Center
        ) {
            when (state) {
                BubbleState.IDLE -> {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Tap to Record Voice",
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }
                BubbleState.RECORDING -> {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Recording... Tap to stop",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
                BubbleState.PROCESSING -> {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = Color.White,
                        strokeWidth = 2.5.dp
                    )
                }
                BubbleState.SUCCESS -> {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Text Injected",
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }
                BubbleState.ERROR -> {
                    Icon(
                        imageVector = Icons.Default.PriorityHigh,
                        contentDescription = "Error",
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }
        }
    }
}