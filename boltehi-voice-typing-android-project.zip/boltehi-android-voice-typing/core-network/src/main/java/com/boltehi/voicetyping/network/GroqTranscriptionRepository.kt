package com.boltehi.voicetyping.network

import com.boltehi.voicetyping.datastore.SettingsRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GroqTranscriptionRepository @Inject constructor(
    private val apiService: GroqApiService,
    private val settingsRepository: SettingsRepository
) {
    suspend fun transcribe(audioFile: File): Result<String> {
        val apiKey = settingsRepository.apiKeyFlow.first()
        if (apiKey.isBlank()) {
            return Result.failure(IllegalStateException("Groq API Key is not configured."))
        }

        val model = settingsRepository.modelFlow.first()
        val language = settingsRepository.languageFlow.first()
        val autoPunctuation = settingsRepository.autoPunctuationFlow.first()

        val requestFile = audioFile.asRequestBody("audio/wav".toMediaTypeOrNull())
        val body = MultipartBody.Part.createFormData("file", audioFile.name, requestFile)
        val modelPart = model.toRequestBody("text/plain".toMediaTypeOrNull())
        val formatPart = "json".toRequestBody("text/plain".toMediaTypeOrNull())

        val langPart = if (language != "auto") {
            language.toRequestBody("text/plain".toMediaTypeOrNull())
        } else null

        val promptPart = if (autoPunctuation) {
            val promptText = if (language == "bn") "যথাযথ বিরামচিহ্ন সহ স্পষ্ট বাংলা বাক্য।" else "Transcribe clearly with standard punctuation."
            promptText.toRequestBody("text/plain".toMediaTypeOrNull())
        } else null

        var lastException: Exception? = null
        for (attempt in 1..3) {
            try {
                val response = apiService.transcribeAudio(
                    authorization = "Bearer $apiKey",
                    file = body,
                    model = modelPart,
                    language = langPart,
                    prompt = promptPart,
                    responseFormat = formatPart
                )

                if (response.isSuccessful) {
                    val text = response.body()?.text ?: ""
                    // Delete temporary audio file immediately for user privacy
                    audioFile.delete()
                    return Result.success(text)
                } else {
                    val code = response.code()
                    if (code == 429) {
                        delay(attempt * 1000L) // Exponential backoff
                        continue
                    }
                    val err = response.errorBody()?.string() ?: "API Error $code"
                    return Result.failure(Exception(err))
                }
            } catch (e: Exception) {
                lastException = e
                delay(attempt * 800L)
            }
        }

        audioFile.delete()
        return Result.failure(lastException ?: Exception("Network request failed after retries"))
    }
}