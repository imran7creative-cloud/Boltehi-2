package com.boltehi.voicetyping

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class VoiceTypingApp : Application() {

    companion object {
        const val OVERLAY_CHANNEL_ID = "voice_typing_overlay_channel"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                OVERLAY_CHANNEL_ID,
                "Voice Typing Floating Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps the floating voice typing bubble active over apps"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }
}