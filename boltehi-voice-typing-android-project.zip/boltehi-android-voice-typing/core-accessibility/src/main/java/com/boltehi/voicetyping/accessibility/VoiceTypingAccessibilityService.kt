package com.boltehi.voicetyping.accessibility

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.lang.ref.WeakReference

class VoiceTypingAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        private var instance: WeakReference<VoiceTypingAccessibilityService>? = null

        fun getInstance(): VoiceTypingAccessibilityService? = instance?.get()
    }

    private var currentFocusedNode: AccessibilityNodeInfo? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = WeakReference(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_FOCUSED,
            AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                val source = event.source ?: return
                if (source.isEditable) {
                    currentFocusedNode?.recycle()
                    currentFocusedNode = AccessibilityNodeInfo.obtain(source)
                }
            }
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                // Find currently focused node in active window
                findActiveFocusedNode()
            }
        }
    }

    private fun findActiveFocusedNode() {
        val root = rootInActiveWindow ?: return
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (focused != null && focused.isEditable) {
            currentFocusedNode?.recycle()
            currentFocusedNode = AccessibilityNodeInfo.obtain(focused)
        }
    }

    /**
     * Injects text directly into the focused field.
     * Fallback to clipboard if node is un-editable or unavailable.
     */
    fun injectText(transcribedText: String): Boolean {
        // Refresh focused node in case window changed
        findActiveFocusedNode()

        val node = currentFocusedNode
        if (node == null || !node.isEditable) {
            return false // Trigger clipboard fallback in caller
        }

        return try {
            val existingText = node.text?.toString() ?: ""
            val selectionStart = node.textSelectionStart
            val selectionEnd = node.textSelectionEnd

            val newText = if (selectionStart in 0..selectionEnd && selectionStart <= existingText.length) {
                // Insert at cursor position or replace active selection
                StringBuilder(existingText)
                    .replace(selectionStart, selectionEnd, " " + transcribedText.trim())
                    .toString()
            } else {
                // Append with space if existing text present
                if (existingText.isNotBlank()) "$existingText $transcribedText" else transcribedText
            }

            val arguments = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, newText)
            }
            node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    override fun onInterrupt() {
        currentFocusedNode?.recycle()
        currentFocusedNode = null
    }

    override fun onDestroy() {
        super.onDestroy()
        currentFocusedNode?.recycle()
        currentFocusedNode = null
        instance = null
    }
}